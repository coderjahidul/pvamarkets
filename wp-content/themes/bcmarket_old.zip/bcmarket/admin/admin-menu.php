<div class="partner-menu">
    <button class="button"><img src="<?php echo get_template_directory_uri(); ?>/img/menu-icons/line-menu.svg" /><span>Menu Cabinet</span></button>
    <ul class="partner-menu-items partner-menu-mobile-hide">

        <li class="partner-menu-item">
            <a href="/admin-interface/" class="<?php if($_SERVER['REQUEST_URI'] == '/admin-interface/'){echo 'partner-menu__active';} ?>">All</a>
        </li>
        <li class="partner-menu-item">
            <a href="/admin-interface/bid-request/" class="<?php if(get_query_var('bid-request')){echo 'partner-menu__active';} ?>">Bid Request</a>
        </li>
        <li class="partner-menu-item">
            <a href="/admin-interface/admin-chat/" class="<?php if(get_query_var('admin-chat')){echo 'partner-menu__active';} ?>">Admin Chat</a>
        </li>
        <li class="partner-menu-item">
            <a href="/admin-interface/payment/" class="<?php if(get_query_var('payment')){echo 'partner-menu__active';} ?>">Payment</a>
        </li>
        <li class="partner-menu-item">
            <a href="/admin-interface/partnerdata/" class="<?php if(get_query_var('partnerdata')){echo 'partner-menu__active';} ?>">Partner</a>
        </li>
        <li class="partner-menu-item">
            <a href="/admin-interface/buyerdata/" class="<?php if(get_query_var('buyerdata')){echo 'partner-menu__active';} ?>">Buyer</a>
        </li>
        <li class="partner-menu-item">
            <a href="/admin-interface/itemdata/" class="<?php if(get_query_var('itemdata')){echo 'partner-menu__active';} ?>">Items</a>
        </li>
        <li class="partner-menu-item">
            <a href="/admin-interface/aorders/" class="<?php if(get_query_var('aorders')){echo 'partner-menu__active';} ?>">Orders</a>
        </li>
    </ul>
</div>