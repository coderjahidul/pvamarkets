<?php

require_once __DIR__.'/vendor/autoload.php';

/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              https://sinek.io
 * @since             1.0.0
 * @package           Sinek
 *
 * @wordpress-plugin
 * Plugin Name:       Sinek
 * Description:       Sinek payment gateway for WooCommerce
 * Version:           1.0.0
 * Author:            sinek
 * Author URI:        https://sinek.io
 * Text Domain:       sinek
 */

use App\Includes\ViserActivator;
use App\Includes\ViserPlugin;

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Currently plugin version.
 * Rename this for your plugin and update it as you release new versions.
 */
define('VISER_PLUGIN_VERSION', '1.0.0');
define('VISER_PLUGIN_NAME', 'sinek');
define('VISER_ROOT', plugin_dir_path(__FILE__));
define('VISER_PLUGIN_URL', str_replace('index.php','',plugins_url( 'index.php', __FILE__ )));



$activator = new ViserActivator();


register_activation_hook( __FILE__, [$activator, 'activate']);
register_deactivation_hook( __FILE__, [$activator, 'deactivate']);



function sinek_init()
{

	if ( !class_exists( 'WC_Payment_Gateway' ) ) return;

	include 'gateway/class-sinek-gateway.php';
	include 'gateway/class-stripe-gateway.php';
	include 'gateway/class-paypal-gateway.php';
	include 'gateway/class-nmi-gateway.php';
	include 'gateway/class-authorize-gateway.php';

	add_filter( 'woocommerce_payment_gateways', 'sinek_gateway' );

	function sinek_gateway( $methods )
	{

		$methods[] = 'StripeGateway';
		$methods[] = 'PaypalGateway';
		$methods[] = 'NmiGateway';
		$methods[] = 'AuthorizeGateway';

		return $methods;

	}
	
	if (!get_option('woocommerce_sinek_payment_domain_url') || !get_option('woocommerce_sinek_api_secret')) {
        add_action('admin_notices', 'account_add_notice');
    }
    
    function account_add_notice()
    {
        echo '<div class="notice notice-warning">Please steup your Sinek payment domain and api secret from <a href="' . admin_url('admin.php?page=wc-settings') . '">WooCommerce General Setting</a>.</div>';
    }

}
add_action( 'plugins_loaded', 'sinek_init' );


$plugin = new ViserPlugin();
$plugin->run();