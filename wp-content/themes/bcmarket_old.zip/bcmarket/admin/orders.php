<?php 
if(is_user_logged_in()){
    $current_user = wp_get_current_user();
    $roles = array('administrator', 'employee');
    $found = 0; 
    foreach($roles as $role){
        if(in_array( $role, (array) $current_user->roles) ){
            $found = 1;
           
        }
    }

    if($found == 0){
         wp_redirect( home_url('/my/') );
            exit(); 
    }
    
}else{
    wp_redirect( home_url('/my/') );
    exit(); 
}
get_header(); ?>

<section class="soc-category" id="content">
    
    <?php get_template_part('template-parts/admin', 'breadcrumb'); ?>

    <div class="container">
        <div class="flex">
            <h1><?php the_title(); ?></h1>
           
            <?php get_template_part( 'admin/admin', 'menu'); ?>
            <div class="body partner_cabinet">

                <div class="search_user_by">
                    <form action="<?php echo 'https://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']; ?>">
                        <input type="text" placeholder="Search by ID or Email" name="query" value="<?php if(isset($_GET['query'])){echo $_GET['query']; } ?>">
                        <button type="submit">Search</button>
                    </form>
                </div>
             
                <?php 

                    $paged = ( get_query_var( 'paged' ) ) ? get_query_var( 'paged' ) : 1;
                    

                    if(isset($_GET['query']) && !empty($_GET['query']) ) {
                         $args = array(
                            'post_type'  => 'shop_order',
                            'post_status' => array_keys( wc_get_order_statuses() ),
                            'paged' => $paged,
                            'posts_per_page' => 50, 
                            'meta_query' => array(
                                array(
                                    'key' => '_order_number', 
                                    'value' => $_GET['query']
                                )
                            )
                        );
                        $orders = new WP_Query($args);
                    }else{
                        $args = array(
                            'post_type'  => 'shop_order',
                            'post_status' => array_keys( wc_get_order_statuses() ),
                            'paged' => $paged,
                            'posts_per_page' => 50
                        );
                        $orders = new WP_Query($args);
                    }


                    if($orders) : ?>

                        <table class="bids list zebra ac">
                            <tbody>
                                <tr>
                                    <th>Id</th>
                                    <th>Buyer Id</th>
                                    <th>Partner Id</th>
                                    <th>Product Id</th>
                                    <th>Qty</th>
                                    <th>Order total</th>
                                    <th>Date</th>
                                    <th>Payment Method</th>
                                    <th>Invalid Item</th>
                                </tr>

                                <?php 
                                while($orders->have_posts()) : $orders->the_post(); 
                                    $order = wc_get_order( get_the_ID() );
                                    foreach ( $order->get_items() as $item_id => $item ) : 
                                    ?>
                                        <tr>
                                            <td><?php echo $order->get_order_number(); ?></td>
                                            <td><?php echo $order->get_user_id(); ?></td>
                                            <td>
                                                <?php 
                                                    
                                                    $product_id = $item->get_product_id();
                                                    echo get_post_field( 'post_author', $product_id );
                                                    
 
                                                ?>
                                            </td>
                                            <td>
                                                <?php echo get_post_meta($product_id, 'custom_product_id', true); ?>
                                            </td>
                                            <td>
                                                <?php echo $item->get_quantity(); ?>
                                            </td>
                                            <td>
                                                <?php echo wc_price($item->get_total()); ?>
                                            </td>
                                            <td>
                                                <?php echo $order->get_date_created(); ?>
                                            </td>
                                            <td>
                                                <?php echo $order->get_payment_method_title(); ?>
                                            </td>
                                            <td class="invalid" date-itemid="<?php echo $item_id; ?>" data-id="<?php echo $item_id; ?>">
                                                <input type="number" name="invalid_item" placeholder="Add Total Invalid" value="<?php echo $item->get_meta( 'invalid_items', true ); ?>">
                                            </td>
                                        </tr>
                                    <?php endforeach;

                                endwhile; wp_reset_postdata(); ?>
                               
                            </tbody>
                        </table>

                <?php else : echo 'No Order found!'; endif; ?>

                <div class="pager_wrap">
                    <?php 
                        $big = 999999999; // need an unlikely integer

                            $paginations_array =  paginate_links( array(
                                'base' => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
                                'format' => '?paged=%#%',
                                'current' => max( 1, get_query_var('paged') ),
                                'total' => $orders->max_num_pages, 
                                'type' => 'array'
                            ) );


                        ?>

                    <?php if($paginations_array) : ?>
                        <div class="pager">
                            <table>
                                <tbody>
                                    <tr>
                                        <?php foreach($paginations_array as $pag_item) : ?>
                                            <td><?php echo $pag_item; ?></td>
                                        <?php endforeach; ?>
                                    </tr>
                                </tbody>
                            </table>
                            <div class="cb"></div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</section>

<?php get_footer() ?>