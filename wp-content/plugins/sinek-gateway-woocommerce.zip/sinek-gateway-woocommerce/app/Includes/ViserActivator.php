<?php

namespace App\Includes;

class ViserActivator{

    public function activate() {
        
    }
    
    public function deactivate() {
       
	}
}