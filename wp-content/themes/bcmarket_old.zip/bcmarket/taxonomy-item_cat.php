<?php
defined( 'ABSPATH' ) || exit;

get_header( );

$term = get_queried_object();
$parent = ( isset( $term->parent ) ) ? get_term_by( 'id', $term->parent, 'item_cat' ) : false;

?>
<section class="soc-category" id="content">
    <div class="wrap-breadcrumbs">
        <div class="container">
            <div class="flex">
                <div class="block" itemscope="" itemtype="http://schema.org/BreadcrumbList" id="breadcrumbs">
                    <div itemprop="itemListElement" itemscope="" itemtype="http://schema.org/ListItem">
                        <a href="<?php echo esc_url(home_url( '/' )); ?>" itemprop="item">
                            <span itemprop="name">Home</span>
                            <meta itemprop="position" content="0">
                        </a>
                        <span class="divider">/</span>
                    </div>
                    <?php if( $parent ): ?>
	                    <div itemprop="itemListElement" itemscope="" itemtype="http://schema.org/ListItem">
	                        <a href="<?php echo get_term_link($parent); ?>" itemprop="item">
	                            <span itemprop="name"><?php echo $parent->name; ?></span>
	                            <meta itemprop="position" content="1">
	                        </a>
	                        <span class="divider">/</span>
	                    </div>
	                <?php endif; ?>
                    <div itemprop="itemListElement" itemscope="" itemtype="http://schema.org/ListItem">
                        <span class="current" itemprop="name"><?php woocommerce_page_title(); ?></span>
                        <meta itemprop="position" content="2">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="flex">
        	<?php if( $parent ): ?>
        		<h1><?php echo $parent->name; ?> accounts for sale - <?php woocommerce_page_title(); ?></h1>
        	<?php else : ?>
            	<h1><?php woocommerce_page_title(); ?></h1>
            <?php endif; ?>
            <div class="soc-bl">
                <div class="soc-title" data-help="Softregs are accounts registered by a special program automatically">
                    <h2 class="soc-name" data-id="10"><?php woocommerce_page_title(); ?></h2>
                    <p class="soc-qty">In stock</p>
                    <p class="soc-cost-label"></p>
                    <p class="soc-cost">Price</p>
                    <p class="soc-control"></p>
                </div>

                <?php 
					while ( have_posts() ) {
						the_post(); 
						wc_get_template_part( 'template-parts/content', 'item' );
                	}
				?>
                
            </div>
            <div class="recat">
                <?php echo get_term_meta(get_queried_object_id(), 'long_description', true); ?>
            </div>
        </div>
    </div>
</section>


<?php get_footer( 'shop' );
