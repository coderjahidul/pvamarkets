<?php

namespace App\Includes;

class WCSetting{
    public function init()
    {
        add_filter('woocommerce_general_settings', [$this,'sinekSetting']);
        
    }

    public function sinekSetting($settings) {
        foreach( $settings as $values ){
            $new_settings[] = $values;

            if($values['id'] == 'woocommerce_calc_discounts_sequentially'){
                $new_settings[] = array(
                    'title'    => __('Sinek API Secret'),
                    'id'       => 'woocommerce_sinek_api_secret',
                    'default'  => '',
                    'desc'     => __("It will validate your IPN"),
                    'type'     => 'text',
                    'desc_tip' => false, // or false
                );
                $new_settings[] = array(
                    'title'    => __('Sinek Payment Domain URL'),
                    'id'       => 'woocommerce_sinek_payment_domain_url',
                    'default'  => '',
                    'type'     => 'text',
                    'desc'     => __("Payment will handle via this domain"),
                    'desc_tip' => false, // or false
                );
            }
        }
        return $new_settings;
    }
}