<p>
	<a href="<?php esc_url(home_url('/')); ?>" target="_blank">
		<?php echo wp_get_attachment_image(get_theme_mod( 'custom_logo' ), 'medium', false, array('style' => 'display:block;margin-left:auto;margin-right:auto')); ?>
	</a>
</p>