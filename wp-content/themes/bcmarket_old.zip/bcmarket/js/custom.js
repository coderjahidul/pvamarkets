jQuery(document).ready(function($){

	/*$(document).on('click', '.registration-open', function(){

		$('.reg-shadow').addClass('reg-open');

	});*/

});