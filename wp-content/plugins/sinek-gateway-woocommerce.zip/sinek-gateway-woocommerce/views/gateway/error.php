<?php
$messages = $viserData['message'];

foreach ($messages as $key => $message) {
    echo "$message <br>";
}

?>