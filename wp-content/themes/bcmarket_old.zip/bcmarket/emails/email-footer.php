<p style="text-align:center">
	<span style="font-size:15px">______________________________<wbr>____________________</span>
</p>
<p style="text-align:center">
	<span style="font-size:13px">
		<a href="<?php echo esc_url(home_url('/')); ?>" target="_blank">Back to store</a>&nbsp;|&nbsp;
		<a href="<?php echo esc_url(home_url('/tickets/new')); ?>" target="_blank" >Ask a question</a>&nbsp;|&nbsp;
		<a href="<?php echo esc_url(home_url('/tickets/new')); ?>" target="_blank">&nbsp;Problems with the order</a>&nbsp;|&nbsp;
		<a href="https://t.me/accountsseller360" target="_blank">5% discount on&nbsp;Telegram</a>&nbsp;
	</span>
</p>


<p style="text-align:center"><span style="color:#999999;font-size:12px">The message was created automatically and it does not require a reply</span></p>
<p style="text-align:center"><span style="color:#999999;font-size:12px">Copyright ©&nbsp; <?php echo get_bloginfo('name'); ?> <?php echo date('Y'); ?>.</span></p>
<p style="text-align:center">&nbsp;</p>