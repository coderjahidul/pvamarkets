<?php

namespace App\Includes;

class RegisterAssets{
    public static $styles = [
        
    ];
    public static $scripts = [
        
    ];
}