<?php get_template_part('emails/email', 'header'); ?> 
<h1 style="text-align:center">
	<span style="font-size:22px">How to get a discount for all the products of Accountsseller.com</span>
</h1>
<p style="text-align:center">
	<span style="font-size:18px">We often give discounts to our telegram channel subscribers - <a href="https://t.me/accountsseller360" target="_blank">@accountsseller360</a>. The discounts are not permanent but they are updated constantly, so it makes sense to subscribe to our channel and be in on this always. 
	</span>
</p>
<?php get_template_part('emails/email', 'footer'); ?> 