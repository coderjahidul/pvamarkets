<div class="wrap-breadcrumbs">
    <div class="container">
        <div class="flex">
            <div class="block" itemscope="" itemtype="http://schema.org/BreadcrumbList" id="breadcrumbs">
                <div itemprop="itemListElement" itemscope="" itemtype="http://schema.org/ListItem">
                    <a href="/" itemprop="item">
                        <span itemprop="name">Home</span>
                        <meta itemprop="position" content="0" />
                    </a>
                    <span class="divider">/</span>
                </div>
                <div itemprop="itemListElement" itemscope="" itemtype="http://schema.org/ListItem">
                    <span class="current" itemprop="name">Admin interface</span>
                    <meta itemprop="position" content="1" />
                </div>
            </div>
        </div>
    </div>
</div>